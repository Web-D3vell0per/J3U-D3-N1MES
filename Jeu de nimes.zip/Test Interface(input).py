#-*- coding: utf-8 -*-
import pygame 
from pygame import * 
import unicodedata

pygame.init()
Running=True
pygame.display.set_caption('Jeu de Nîmes')

#GameScreen
icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
pygame.display.set_icon(icon)
screen=pygame.display.set_mode((1080,720))
clock=pygame.time.Clock()

#Init Players
nom_joueur_1=''
nom_joueur_2=''
joueur1_baton = 0
joueur2_baton = 0
nombre_max_baton=21

#Text
base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
user_text=''
Intro_txt='Bienvenue au jeu de nimes,entrez le nom du J1'
text_surface=base_font.render(Intro_txt,True,(0,0,0))

#Creation of a rectangle
input_rect=pygame.Rect(50,600,-640,62)
Rect_color=pygame.Color('Black')

#========================================================
def NOM():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')

    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

#Text
    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    user_text=''
    global nom_joueur_1

#Creation of a rectangle for the Input
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')

#GameLoop
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT

            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_BACKSPACE:
                    user_text = user_text[0:-1]
                else:   
                    user_text += event.unicode
                
                if event.key==pygame.K_KP_ENTER:
                        user_text = user_text[0:-1]
                        nom_joueur_1=user_text
                        introj2()
                        
                if event.key==pygame.K_ESCAPE:
                    introj2()

    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(user_text,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)        
#========================================================
def introj2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Intro_txt='Bienvenue au jeu de nimes,entrez le nom du J2'

    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
     
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               NOMJ2()
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Intro_txt,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60) 
#========================================================
def NOMJ2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')

    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

#Text
    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    user_text=''
    global nom_joueur_2

#Creation of a rectangle for the Input
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')

#GameLoop
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT

            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_BACKSPACE:
                    user_text = user_text[0:-1]
                else:   
                    user_text += event.unicode
                
                if event.key==pygame.K_KP_ENTER:
                        user_text = user_text[0:-1]
                        nom_joueur_2=user_text
                        Batons()

    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(user_text,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60) 
#========================================================
def Batons():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Intro_txt='Nombre de batons que {} veut retirer ?'.format(nom_joueur_1)

    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
     
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Input()
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Intro_txt,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)        
#========================================================
def Input():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')

    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

#Text
    global nombre_max_baton
    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    user_text=''

#Creation of a rectangle for the Input
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')

#GameLoop
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT

            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_BACKSPACE:
                    user_text = user_text[0:-1]
                else:   
                    user_text += event.unicode
                if event.key==pygame.K_KP_1 or K_KP_2 or K_KP_3:
                    if event.key==pygame.K_KP_ENTER:
                        joueur1_baton=int(user_text)
                        nombre_max_baton=nombre_max_baton - joueur1_baton
                        Nb_batons()

    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(user_text,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)
#========================================================
def Nb_batons():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')
    global nombre_max_baton
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Nombres="il reste {} baton".format(nombre_max_baton)
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
    
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Batons2()
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Nombres,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)
#========================================================
def Batons2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Intro_txt='Nombre de batons que {} veut retirer ?'.format(nom_joueur_2)

    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
     
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Input2()
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Intro_txt,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)        
#========================================================
def Input2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')

    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

#Text
    global nombre_max_baton
    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    user_text=''

#Creation of a rectangle for the Input
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')

#GameLoop
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT

            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_BACKSPACE:
                    user_text = user_text[0:-1]
                else:   
                    user_text += event.unicode
                if event.key==pygame.K_KP_1 or K_KP_2 or K_KP_3:
                    if event.key==pygame.K_KP_ENTER:
                        joueur1_baton=int(user_text)
                        nombre_max_baton=nombre_max_baton - joueur1_baton
                        Nb_batons2()

    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(user_text,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)
#========================================================
def Nb_batons2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Jeu de Nîmes')
    global nombre_max_baton
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Nombres="il reste {} baton".format(nombre_max_baton)
    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
    
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Batons()
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Nombres,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60)
#========================================================
#GameLoop w/ function
while Running:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
            pygame.QUIT

        if event.type==pygame.MOUSEBUTTONDOWN:
            NOM()
        if nombre_max_baton==0:
            pass
    #Change colors of the screen 
    screen.fill((255,255,255))  
    pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
    screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    input_rect.w=text_surface.get_width()+10
    pygame.display.flip()
    clock.tick(60)

#https://youtu.be/Rvcyf4HsWiw(Text Input Tutoriel)
#========================================================
def Victory1():
    pygame.init()
    Running=True
    pygame.display.set_caption('Victoire!!!')
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Intro_txt='{} à gagné'.format(nom_joueur_1)

    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
     
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Running = False
               pygame.QUIT
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Intro_txt,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60) 
#========================================================  
def Victory2():
    pygame.init()
    Running=True
    pygame.display.set_caption('Victoire!!!')
    #GameWindow
    icon=pygame.image.load('Python/Jeu de Nîmes/icon.jpg',"Icone")
    pygame.display.set_icon(icon)
    screen=pygame.display.set_mode((1080,720))
    clock=pygame.time.Clock()

    base_font= pygame.font.Font('Python/Jeu de Nîmes/PKMN RBYGSC.ttf',32)
    Intro_txt='{} à gagné'.format(nom_joueur_2)

    input_rect=pygame.Rect(50,600,-640,62)
    Rect_color=pygame.Color('Black')
     
    while Running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False
                pygame.QUIT
            if event.type==pygame.MOUSEBUTTONDOWN:
               Running = False
               pygame.QUIT
    #Change colors of the screen 
        screen.fill((255,255,255))  
        pygame.draw.rect(screen,Rect_color,input_rect,1)  
    
    #Change colors of the txt 
        text_surface=base_font.render(Intro_txt,True,(0,0,0))
        screen.blit(text_surface,(input_rect.x + 5,input_rect.y + 5))
    
        input_rect.w=text_surface.get_width()+10
        pygame.display.flip()
        clock.tick(60) 
#========================================================







